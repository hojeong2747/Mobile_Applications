package ddwu.mobile.place.placebasic;

import java.util.List;

import ddwu.mobile.place.placebasic.pojo.PlaceBasic;

public interface OnPlaceBasicResult {
    public void onPlaceBasicResult(List<PlaceBasic> places);

}
