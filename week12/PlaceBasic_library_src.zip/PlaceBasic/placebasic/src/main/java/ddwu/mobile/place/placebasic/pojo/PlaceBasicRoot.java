package ddwu.mobile.place.placebasic.pojo;

import java.util.List;

public class PlaceBasicRoot {
    List<PlaceBasic> results;

    public List<PlaceBasic> getResults() {
        return results;
    }

    public void setResults(List<PlaceBasic> results) {
        this.results = results;
    }
}
